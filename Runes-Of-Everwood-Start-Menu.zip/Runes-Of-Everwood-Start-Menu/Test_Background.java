import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Test_Background here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Test_Background extends World
{

    /**
     * Constructor for objects of class Test_Background.
     * 
     */
    public Test_Background()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1080,800
        , 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Button1 button1 = new Button1();
        addObject(button1,485,618);
   

        Button3 button3 = new Button3();
        addObject(button3,482,799);
        button3.setLocation(500,758);
        button3.setLocation(466,767);
        button3.setLocation(489,767);
        button3.setLocation(483,767);
     
        button1.setLocation(472,621);
        button1.setLocation(488,620);
        button1.setLocation(482,622);
      
        button1.setLocation(518,629);
        button1.setLocation(485,633);
    }
}
